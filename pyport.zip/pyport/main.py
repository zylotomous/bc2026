"""UNSW Battlecode dragon bot -- strategy layer, ported from the C++ bot (improved version).

Every dragon runs its own copy. Each turn it scores every legal action (single steps, short sprints,
splits, feeding) with a one-ply model of what the dragons around it can do before its next turn and
plays the best. Team behaviour emerges from shared deterministic rules: split early into a swarm that
spreads over the pearls, trade heads when the trade favours us, and consolidate into one long "king".

This is a faithful port: same parameters, same scoring terms, same fields, same order of decisions.
Port-specific notes are marked "PORT:". The only behavioural addition is a hard CPU guard
(EMERGENCY_BUDGET): if a turn is about to run past what the judge allows, the dragon plays the best
action evaluated so far instead of being killed for exceeding the CPU limit. It never triggers on a
turn the C++ logic fits in; the C++ bot has no need for it because it runs ~100x faster.
"""
import numpy as np

import engine as E
import maps_data as MD
from engine import DCH, INF, M64, manhattan, edgeOf, edgeKind, rnd64, nowNs

# ---------------------------------------------------------------- params (C++ defaults)
P_NOISE = 0.0001
END_START = 400
UNIT_VALUE = 1.5
AGGRESSION = 1.5
AGGR_BAL = 1.5
SPLIT_BONUS = 2.0
POT_W = 1.0
CROWD_W = 0.12
LAMBDA = 0.85
FAR_LAMBDA = 0.96
FAR_W = 0.0
PORTAL_W = 0.0
PORTAL_RISK = 0.4
PROBE_CLEAR_RISK = 0.02
PORTAL_WRONGWAY = 0.0
EVEN_TRADE_EARLY = 0.0
EARLY_ROUNDS = 80
TERR_W = 0.0
CONTEND_ALL = True
KING_TERR_W = 0.9
RAM_REL = False
HUNT_ON = True
EXPOSE_ALL = True
USE_DENSITY = True
DENS_MUL = 1.5
KING_START = 150            # improved version (original: 60)
NO_KING_SPLIT = True
KING_POT_MUL = 1.5
KING_PRIORITY = True
KING_VAL_MUL = 2.0
KING_VAL_ADD = 10.0
UNIT_TARGET = 64
SURV_ON = False
SURV_DEPTH = 10
SURV_NODE_LIMIT = 6000
SURV_KING = True
SURV_KING_DEPTH = 14
POT_DEPTH = 90
EAT_W = 3.0
THR_P2 = 0.35
THR_P3 = 0.15
EVEN_EXPOSE = 0.1
LAST_UNIT_PEN = 5.0
SPRINT_W = 3.0
THR_MIN = 0.5
DENS_REL = False
BEST_W = 2.0
BEST_LAMBDA = 0.88
YIELD_W = 0.0
YIELD_LAMBDA = 0.9
YIELD_DEPTH = 30
YIELD_SHARE = 0.25
YIELD_EXCESS = 1.0
KING_LONGEST = False
KING_MARGIN = 4
R_GATHER = 340
R_FEED = 400
R_EARLYFEED = 1000
FEED_RADIUS = 8
FEED_RADIUS_LATE = 16
PIPE_START = 1000
PIPE_R0 = 5.0
PIPE_R1 = 30.0
PIPE_MINLEN = 3
FINALE = 470
P_SEED = 0

SOFT_BUDGET = 45_000_000       # judge points (== virtual ns), as in C++
JUDGE_LIMIT = 100_000_000      # PORT: the judge kills a dragon whose turn costs more than this
WRITE_RESERVE = 6_000_000      # PORT: one write costs 2.5M + 4k/byte; keep room for it and slack
worstEval = 3_000_000          # PORT: costliest single candidate evaluation seen so far
turnStartNs = 0


def spentNs():
    return nowNs() - turnStartNs


powLam = np.array([LAMBDA ** i for i in range(256)])
powFar = np.array([FAR_LAMBDA ** i for i in range(256)])
powKeep = np.array([0.985 ** i for i in range(256)])
powY = np.array([YIELD_LAMBDA ** i for i in range(256)])
powBest = np.array([BEST_LAMBDA ** i for i in range(256)])

# ---------------------------------------------------------------- per-turn fields
freeAtO = {}          # others' bodies: earliest step a tile may be entered (sparse; default 0)
freeAtAll = {}        # others + my current body
contested = set()     # PORT: written but never read in the C++ either; kept for parity
distMe = distAlly = distEnemy = None        # Python lists (T)
gateAll = None        # numpy (T+1) freeAtAll with sentinel blocked, for vectorised BFS
_scratch = None
_arange = None
potCache = {}
yCache = {}


def isEnemyTeam(team):
    return team >= 0 and team != E.myTeam


# Static dead ends: repeatedly prune tiles with at most one open neighbour (corridors and pockets
# that lead nowhere: fine for a short dragon, deadly for a long king).
deadEnd = None        # list of bool
deadEnd_np = None
deadEndMapIndex = -99


def computeDeadEnds():
    """PORT: the C++ peels with a queue; this peels a whole layer at a time with numpy. Peeling to
    'every remaining tile has >= 2 exits' has a unique result, so the set is identical."""
    global deadEnd, deadEnd_np, deadEndMapIndex
    if deadEndMapIndex == E.mapIndex:
        return
    deadEndMapIndex = E.mapIndex
    T = E.T
    st = E.stepTo
    valid = (st >= 0) & (st != np.arange(T, dtype=np.int32)[:, None])
    deg = valid.sum(1).astype(np.int64)
    dead = deg <= 1
    frontier = np.flatnonzero(dead)
    while frontier.size:
        nbs = st[frontier].ravel()
        nbs = nbs[nbs >= 0]
        nbs = nbs[~dead[nbs]]
        if nbs.size:
            deg -= np.bincount(nbs, minlength=T)
        newdead = (~dead) & (deg <= 1)
        dead |= newdead
        frontier = np.flatnonzero(newdead)
    deadEnd_np = np.zeros(T + 1, dtype=bool)
    deadEnd_np[:T] = dead
    deadEnd = dead.tolist()


def buildFreeAt():
    global freeAtO, freeAtAll, contested, gateAll
    fo = {}
    contested = set()
    step_l = E.step_l
    myId = E.myId
    for dv in E.dragons:
        if dv.id == myId:
            continue
        L = dv.len if dv.exact else dv.len + 3
        if dv.head >= 0:
            for i, t in enumerate(dv.chain):
                f = L - i + 1
                if f < 1:
                    f = 1
                if f > fo.get(t, 0):
                    fo[t] = f
            for q in step_l[dv.head]:
                if q >= 0:
                    contested.add(q)
    for i, p in enumerate(E.parts):
        if p[0] == myId:
            continue
        t = E.partTile[i]
        if fo.get(t, 0) == 0:
            fo[t] = 6
    # Forced moves: a dragon with a single legal move will make it (lanes, corridors). Follow such
    # chains a few steps and block the tiles they will fill.
    myb = set(E.myBody)
    for dv in E.dragons:
        if dv.id == myId or dv.head < 0:
            continue
        L = dv.len if dv.exact else dv.len + 2
        h = dv.head
        neck = dv.chain[1] if len(dv.chain) > 1 else -1
        for k in range(1, 5):
            only, nOpt = -1, 0
            for v in step_l[h]:
                if v < 0 or v == neck:
                    continue
                if k < fo.get(v, 0):
                    continue
                if k == 1 and v in E.vis_set and v in E.occ:
                    continue
                if v in myb:
                    continue
                nOpt += 1
                only = v
            if nOpt != 1:
                break
            f = k + L
            if f > fo.get(only, 0):
                fo[only] = f
            neck = h
            h = only
    fa = dict(fo)
    L = len(E.myBody)
    for i in range(L):
        f = E.myLen - i + 1
        t = E.myBody[i]
        if f > fa.get(t, 0):
            fa[t] = f
    freeAtO, freeAtAll = fo, fa
    g = np.zeros(E.T + 1, dtype=np.int32)
    if fa:
        g[np.fromiter(fa.keys(), dtype=np.int32, count=len(fa))] = np.fromiter(fa.values(), dtype=np.int32, count=len(fa))
    g[E.T] = INF
    gateAll = g


def bfs_np(srcs, gate_base, max_depth):
    """Multi-source time-aware BFS (the C++ bfsField / potential / yield searches), vectorised one
    layer at a time. A tile v at depth d is entered only if d >= gate[v]; visited tiles are closed by
    setting their gate to INF. Returns dist (numpy, T+1, INF for unreached)."""
    gate = gate_base.copy()
    dist = np.full(E.T + 1, INF, dtype=np.int32)
    fr = np.asarray(srcs, dtype=np.int32)
    if fr.size == 0:
        return dist
    dist[fr] = 0
    gate[fr] = INF
    step_np, sc, ar = E.step_np, _scratch, _arange
    d = 0
    while d < max_depth:
        d += 1
        nb = step_np[fr].ravel()
        nb = nb[gate[nb] <= d]
        if not nb.size:
            break
        pos = ar[:nb.size]
        sc[nb] = pos                   # last write wins: keeps exactly one copy of each tile
        nb = nb[sc[nb] == pos]
        dist[nb] = d
        gate[nb] = INF
        fr = nb
    return dist


def bfs_multi(src_lists, gates, max_depth):
    """PORT: several independent BFS searches run as one labelled search. Search s lives in index
    range [s*N, (s+1)*N) (N = T+1), so each search gets exactly the distances bfs_np would give it,
    but every numpy call per layer is shared by all searches (numpy call overhead dominates in the
    judge). Returns an (S, N) distance array."""
    S = len(src_lists)
    N = E.T + 1
    gate = np.concatenate(gates)
    dist = np.full(S * N, INF, dtype=np.int32)
    fr = np.concatenate([np.asarray(sl, dtype=np.int32) + s * N for s, sl in enumerate(src_lists)]).astype(np.int32)
    if fr.size == 0:
        return dist.reshape(S, N)
    dist[fr] = 0
    gate[fr] = INF
    step_np = E.step_np
    sc = np.empty(S * N, dtype=np.int32)
    ar = np.arange(4 * S * N, dtype=np.int32)
    d = 0
    while d < max_depth:
        d += 1
        base = fr - fr % N
        nb = (step_np[fr - base] + base[:, None]).ravel()
        nb = nb[gate[nb] <= d]
        if not nb.size:
            break
        pos = ar[:nb.size]
        sc[nb] = pos
        nb = nb[sc[nb] == pos]
        dist[nb] = d
        gate[nb] = INF
        fr = nb
    return dist.reshape(S, N)


def precomputePotentials(srcs):
    """PORT: fill potentialAt's cache for several source tiles with one batched search. Values are
    identical to computing each potentialAt(src) on its own."""
    srcs = [s for s in dict.fromkeys(srcs) if s not in potCache]
    if not srcs:
        return
    D = bfs_multi([[s] for s in srcs], [gatePot] * len(srcs), POT_DEPTH)
    idx = model_idx
    for i, src in enumerate(srcs):
        dd = D[i][idx]
        sel = (dd < INF) & (idx != src)
        t, d = idx[sel], dd[sel].astype(np.int64)
        acc = best = 0.0
        if t.size:
            val = valueAtVec(t, d)
            pos = val > 0
            if pos.any():
                val, d = val[pos], d[pos]
                acc = float((val * (powLam[d] + FAR_W * powFar[d])).sum())
                best = float((val * powBest[d]).max())
        potCache[src] = acc + BEST_W * best


# ---------------------------------------------------------------- tile value model
TM_NONE, TM_PEARL, TM_SPAWN_AT, TM_REMEMBERED, TM_UNKNOWN_CD, TM_NEVER_SEEN = range(6)
tmKind = tmA = tmMul = None           # numpy (T)
model_idx = None                      # tiles with tmKind != NONE
densityEst = -1.0
densityRel = -1.0
rateRaw = None
rateRawMap = -99


def computeRawRates():
    global rateRaw, rateRawMap
    if rateRawMap == E.mapIndex:
        return
    rateRawMap = E.mapIndex
    gmn = E.gmin.astype(np.float64)
    gmx = E.gmax.astype(np.float64)
    rateRaw = np.where(gmx > 0, 2.0 / (np.maximum(gmn, 0) + np.maximum(gmx, 1)), 0.0)


def updateDensity():
    global densityEst, densityRel
    n = p = 0
    rs = 0.0
    if DENS_REL and E.mapKnown:
        computeRawRates()
    for t in E.visList:
        if E.gmax_l[t] == 0 or t in E.occ:
            continue
        n += 1
        if t in E.pearl_set:
            p += 1
        if DENS_REL and E.mapKnown:
            rs += float(rateRaw[t])
    if n < 5:
        return
    obs = p / n
    densityEst = obs if densityEst < 0 else 0.9 * densityEst + 0.1 * obs
    if DENS_REL and E.mapKnown and rs > 0:
        rel = p / rs
        densityRel = rel if densityRel < 0 else 0.9 * densityRel + 0.1 * rel


def densCap(v, t):
    if not USE_DENSITY or densityEst < 0:
        return v
    if DENS_REL and E.mapKnown and densityRel >= 0:
        cap = np.minimum(1.0, DENS_MUL * densityRel * rateRaw[t]) + 0.02
    else:
        cap = DENS_MUL * densityEst + 0.02
    return np.minimum(v, cap)


def valueAtVec(t, d):
    """valueAt(t, d) for arrays of tiles and arrival times (d turns from now)."""
    k = tmKind[t]
    a = tmA[t]
    rn = E.roundNum
    v = np.zeros(t.size)
    m = k == TM_PEARL
    v[m] = 1.0
    m = k == TM_SPAWN_AT
    if m.any():
        tt, wait = t[m], a[m] - (rn + d[m])
        sv = np.where(wait > 0, 0.8 * powLam[np.clip(wait, 0, 255)], 0.8)
        late = wait <= -5
        if late.any():
            sv[late] = np.maximum(densCap(np.full(late.sum(), 0.8), tt[late]),
                                  0.8 * np.maximum(0.0, 1.0 + 0.03 * (wait[late] + 5)))
        v[m] = sv
    m = k == TM_REMEMBERED
    if m.any():
        v[m] = 0.85 * powKeep[np.minimum(a[m] + d[m], 255)]
    m = k == TM_UNKNOWN_CD
    if m.any():
        tt = t[m]
        gx = E.gmax[tt].astype(np.float64)
        gn = E.gmin[tt].astype(np.float64)
        mg = np.where(gx > 0, 0.5 * (gn + gx), 150.0)
        v[m] = densCap(0.45 * np.minimum(1.0, (a[m] + d[m]) / mg), tt)
    m = k == TM_NEVER_SEEN
    if m.any():
        tt = t[m]
        gn = E.gmin[tt].astype(np.float64)
        gx = E.gmax[tt].astype(np.float64)
        lo = np.where(gn > 0, gn, 1.0)
        hi = np.where(gx > 0, gx, 300.0)
        p = (rn + d[m] - lo + 1) / (hi - lo + 1)
        v[m] = densCap(0.6 * np.clip(p, 0.0, 1.0), tt)
    return v * tmMul[t]


kingVisibleNow = False
kingTileNow = -1
kingIdNow = -1


def computeTileValues():
    """PORT: buildTileModel + contention multiplier for every tile, vectorised. The C++ also fills
    tileVal[], which nothing reads; it is not computed here."""
    global tmKind, tmA, tmMul, model_idx
    T = E.T
    rn = E.roundNum
    kind = np.zeros(T, dtype=np.int8)
    a = np.zeros(T, dtype=np.int64)
    spawnable = E.gmax[:T] != 0
    vis = E.vis_np[:T]
    seen = E.lastSeen >= 0
    # visible tiles
    vl = np.fromiter(E.visList, dtype=np.int32, count=49)
    for t in E.visList:
        if not spawnable[t]:
            continue
        if t in E.pearl_set:
            kind[t] = TM_PEARL
        elif E.countdownNow[t] >= 0:
            kind[t] = TM_SPAWN_AT
            a[t] = rn + E.countdownNow[t]
    # remembered tiles
    inv = spawnable & ~vis
    m = inv & seen & E.pearlMem
    kind[m] = TM_REMEMBERED
    a[m] = rn - E.lastSeen[m]
    m2 = inv & seen & ~E.pearlMem & (E.spawnAt >= 0)
    kind[m2] = TM_SPAWN_AT
    a[m2] = E.spawnAt[m2]
    m3 = inv & seen & ~E.pearlMem & (E.spawnAt < 0)
    kind[m3] = TM_UNKNOWN_CD
    a[m3] = rn - E.lastSeen[m3]
    kind[inv & ~seen] = TM_NEVER_SEEN
    del vl
    # contention multiplier
    mul = np.ones(T)
    has = kind != TM_NONE
    dm = np.asarray(distMe_np[:T])
    meKing = KING_PRIORITY and kingIdNow == E.myId
    sel = has if CONTEND_ALL else (has & vis)
    if not meKing:
        da = distAlly_np[:T]
        mul = np.where(sel & (da < dm), mul * 0.25, np.where(sel & (da == dm), mul * 0.6, mul))
    de = distEnemy_np[:T]
    mul = np.where(sel & (de < dm), mul * 0.6, mul)
    if KING_PRIORITY and kingVisibleNow and E.myId != kingIdNow:
        t = np.arange(T)
        kx, ky = kingTileNow % E.W, kingTileNow // E.W
        dx = np.abs(t % E.W - kx)
        dy = np.abs(t // E.W - ky)
        md = np.minimum(dx, E.W - dx) + np.minimum(dy, E.H - dy)
        mul = np.where(has & (md <= dm + 1), mul * 0.2, mul)
    tmKind, tmA, tmMul = kind, a, mul
    model_idx = np.flatnonzero(has).astype(np.int32)


# Discounted pearl mass reachable from a tile, plus the single best target nearby.
potAvoidDeadEnds = False
gatePot = None


def potentialAt(src):
    if src in potCache:
        return potCache[src]
    dist = bfs_np([src], gatePot, POT_DEPTH)
    idx = model_idx
    dd = dist[idx]
    sel = (dd < INF) & (idx != src)
    t, d = idx[sel], dd[sel].astype(np.int64)
    acc = best = 0.0
    if t.size:
        val = valueAtVec(t, d)
        pos = val > 0
        if pos.any():
            val, d = val[pos], d[pos]
            acc = float((val * (powLam[d] + FAR_W * powFar[d])).sum())
            best = float((val * powBest[d]).max())
    r = acc + BEST_W * best
    potCache[src] = r
    return r


# Yield field: long-run production around a tile (disabled by default: YIELD_W = 0).
rateT = None


def computeRates():
    global rateT
    gmn = E.gmin.astype(np.float64)
    gmx = E.gmax.astype(np.float64)
    r = np.where(gmx > 0, 2.0 / (np.maximum(gmn, 0) + np.maximum(gmx, 1)), 0.0)
    pos = gmx > 0
    base = YIELD_EXCESS * r[pos].sum() / pos.sum() if pos.any() else 0.0
    rateT = np.maximum(0.0, r - base)


def yieldAt(src):
    if src in yCache:
        return yCache[src]
    dist = bfs_np([src], gateAll, YIELD_DEPTH)[:E.T]
    reached = np.flatnonzero((dist < INF) & (rateT > 0))
    du = dist[reached]
    sh = np.where((du < distAlly_np[reached]) & (du < distEnemy_np[reached]), 1.0, YIELD_SHARE)
    acc = float((rateT[reached] * sh * powY[du]).sum())
    yCache[src] = acc
    return acc


# Tiles reachable from the head of `body` (time-aware), up to maxCount. pessimistic: a tile only
# counts if I get there strictly before any enemy head could (and no later than an ally).
lastSpaceQueue = []


def spaceCount(body, ln, maxCount, pessimistic, extra=None):
    global lastSpaceQueue
    step_l = E.step_l
    fo = freeAtO
    seg = {t: i for i, t in enumerate(body)}
    ex = None
    if extra:
        EL = len(extra)
        ex = {t: EL - i + 1 for i, t in enumerate(extra)}
    de, da = distEnemy, distAlly
    src = body[0]
    dist = {src: 0}
    q = [src]
    qh = 0
    count = 1
    lastSpaceQueue = q
    while qh < len(q):
        u = q[qh]
        qh += 1
        du = dist[u]
        if du >= 60:
            continue
        s = du + 1
        for v in step_l[u]:
            if v < 0 or v in dist:
                continue
            f = fo.get(v, 0)
            si = seg.get(v)
            if si is not None:
                fi = ln - si + 1
                if fi > f:
                    f = fi
            if ex is not None:
                fe = ex.get(v)
                if fe is not None and fe > f:
                    f = fe
            if s < f:
                continue
            if pessimistic and (s >= de[v] or s >= da[v]):
                continue
            dist[v] = s
            q.append(v)
            count += 1
            if count >= maxCount:
                return count
    return count


# ---------------------------------------------------------------- survival lookahead
# Depth-limited search over my own future moves: is there a way to stay alive for `depth` turns?
survNodes = 0
survBest = 0


def survivalDepth(body, ln, depth):
    """PORT: the C++ stops after SURV_NODE_LIMIT nodes; that limit was sized for C++ speed. Here the
    search also stops when the turn's CPU budget runs short, exactly as the node limit does (returning
    the deepest survivable depth found so far)."""
    global survNodes, survBest
    L = min(len(body), 200)
    if L == 0:
        return 0
    ring = [0] * 256
    socc = {}
    for i in range(L):
        ring[(1000 + i) & 255] = body[i]
        socc[body[i]] = socc.get(body[i], 0) + 1
    survNodes = 0
    survBest = 0
    step_l, fo, de, da = E.step_l, freeAtO, distEnemy, distAlly
    stop_at = turnStartNs + SOFT_BUDGET

    def dfs(headIdx, s0, neck):
        global survNodes, survBest
        if s0 > survBest:
            survBest = s0
        if s0 >= depth:
            return True
        survNodes += 1
        if survNodes > SURV_NODE_LIMIT or (not survNodes & 63 and nowNs() > stop_at):
            survNodes = SURV_NODE_LIMIT + 1
            return False
        head = ring[headIdx & 255]
        s = s0 + 1
        for v in step_l[head]:
            if v < 0 or v == neck:
                continue
            if socc.get(v, 0) > 0:
                continue
            if s < fo.get(v, 0):
                continue
            if de[v] <= s:
                continue
            if s == 1 and da[v] <= 1:
                continue
            tail = ring[(headIdx + L - 1) & 255]
            ring[(headIdx - 1) & 255] = v
            socc[v] = socc.get(v, 0) + 1
            socc[tail] = socc.get(tail, 0) - 1
            ok = dfs(headIdx - 1, s, head)
            socc[tail] += 1
            socc[v] -= 1
            if ok:
                return True
            if survNodes > SURV_NODE_LIMIT:
                return False
        return False

    dfs(1000, 0, body[1] if L > 1 else -1)
    return survBest


# ---------------------------------------------------------------- threat model
_reachBase = {}


def _reach_base(e, reach):
    """BFS from enemy head e ignoring my new body. Returns (first-discovery distance per tile,
    set of tiles expanded)."""
    key = (e, reach)
    r = _reachBase.get(key)
    if r is not None:
        return r
    step_l, occ, parts, vis, myId = E.step_l, E.occ, E.parts, E.vis_set, E.myId
    dist = {e: 0}
    hit = {}
    q = [e]
    qh = 0
    while qh < len(q):
        u = q[qh]
        qh += 1
        du = dist[u]
        if du >= reach:
            continue
        for v in step_l[u]:
            if v < 0 or v in dist:
                continue
            if v not in hit:
                hit[v] = du + 1
            if v in vis:
                oi = occ.get(v, -1)
                if oi >= 0 and parts[oi][0] != myId:
                    continue
            dist[v] = du + 1
            q.append(v)
    r = (hit, dist)
    _reachBase[key] = r
    return r


def reachSteps(e, target, reach, newBody):
    """Steps the head at e needs to step into `target` (<= reach), or INF. Obstacles: visible bodies
    and my new body. PORT: exact shortcut -- if the obstacle-free-of-my-body search never expanded a
    tile of my new body (other than the target), the full search explores identically and gives the
    same answer; otherwise the full search below runs, as in C++."""
    hit, expanded = _reach_base(e, reach)
    clean = True
    for b in newBody:
        if b != target and b in expanded:
            clean = False
            break
    if clean:
        h = hit.get(target, INF)
        return h if h <= reach else INF
    step_l, occ, parts, vis, myId = E.step_l, E.occ, E.parts, E.vis_set, E.myId
    nb = set(newBody)
    dist = {e: 0}
    q = [e]
    qh = 0
    while qh < len(q):
        u = q[qh]
        qh += 1
        du = dist[u]
        if du >= reach:
            continue
        for v in step_l[u]:
            if v < 0 or v in dist:
                continue
            if v == target:
                return du + 1
            if v in nb:
                continue
            if v in vis:
                oi = occ.get(v, -1)
                if oi >= 0 and parts[oi][0] != myId:
                    continue
            dist[v] = du + 1
            q.append(v)
    return INF


def unseenDist(src, body, maxD):
    """Steps from src to the nearest tile I cannot see (unseen tiles may hide an attacker)."""
    step_l, occ, parts, vis, myId = E.step_l, E.occ, E.parts, E.vis_set, E.myId
    nb = set(body)
    dist = {src: 0}
    q = [src]
    qh = 0
    while qh < len(q):
        u = q[qh]
        qh += 1
        du = dist[u]
        if du >= maxD:
            continue
        for v in step_l[u]:
            if v < 0 or v in dist:
                continue
            if v not in vis:
                return du + 1
            if v in nb:
                continue
            oi = occ.get(v, -1)
            if oi >= 0 and parts[oi][0] != myId:
                continue
            dist[v] = du + 1
            q.append(v)
    return INF


def reachOf(dv):
    L = dv.len if dv.exact else dv.len + 1
    r = L - 1
    return 1 if r < 1 else (6 if r > 6 else r)


# ---------------------------------------------------------------- comms
# Sonar gossip: which of our dragons is the king, where it was and when, and the biggest enemy seen
# lately, with a 16-bit keyed check. bits 0..15 check, 16..18 type, 19..30 tile, 31..38 len,
# 39..47 round, 48..59 id, 60 crowned.
SECRET = 0xB5AD4ECEDA1CE2A9
MSG_KING, MSG_ENEMY = 1, 2
KING_STALE = 25
ENEMY_STALE = 12


class KInfo:
    __slots__ = ("valid", "id", "tile", "len", "round", "crowned")

    def __init__(self):
        self.valid = False
        self.id = -1
        self.tile = -1
        self.len = 0
        self.round = -1000
        self.crowned = False

    def copy(self):
        k = KInfo()
        k.valid, k.id, k.tile, k.len, k.round, k.crowned = self.valid, self.id, self.tile, self.len, self.round, self.crowned
        return k


bestKing = KInfo()
enemyBig = KInfo()
wasKing = False


def mix64(x):
    x ^= x >> 33
    x = (x * 0xff51afd7ed558ccd) & M64
    x ^= x >> 33
    x = (x * 0xc4ceb9fe1a85ec53) & M64
    x ^= x >> 33
    return x


def encodeMsg(typ, k):
    p = 0
    p |= (typ & 7) << 16
    p |= (k.tile & 0xFFF) << 19
    p |= (min(k.len, 255) & 0xFF) << 31
    p |= (k.round & 0x1FF) << 39
    p |= (k.id & 0xFFF) << 48
    if k.crowned:
        p |= 1 << 60
    check = mix64(p ^ SECRET ^ E.myTeam) & 0xFFFF
    return p | check


def decodeMsg(v):
    p = v & ~0xFFFF & M64
    if (mix64(p ^ SECRET ^ E.myTeam) & 0xFFFF) != (v & 0xFFFF):
        return None
    typ = (v >> 16) & 7
    k = KInfo()
    k.valid = True
    k.tile = (v >> 19) & 0xFFF
    k.len = (v >> 31) & 0xFF
    r9 = (v >> 39) & 0x1FF
    r = (E.roundNum & ~0x1FF) | r9   # rounds are < 512: latest round <= now with these low 9 bits
    if r > E.roundNum:
        r -= 512
    k.round = r
    k.id = (v >> 48) & 0xFFF
    k.crowned = bool((v >> 60) & 1)
    if k.tile >= E.T or k.len < 1:
        return None
    if typ not in (MSG_KING, MSG_ENEMY):
        return None
    return typ, k


def fresher(a, b, stale):
    aOk = a.valid and E.roundNum - a.round <= stale
    bOk = b.valid and E.roundNum - b.round <= stale
    if not aOk:
        return False
    if not bOk:
        return True
    if a.id == b.id:
        return a.round > b.round or (a.round == b.round and a.len > b.len)
    if a.len != b.len:
        return a.len > b.len
    return a.id < b.id


def kingBetter(a, b):
    aOk = a.valid and E.roundNum - a.round <= KING_STALE
    bOk = b.valid and E.roundNum - b.round <= KING_STALE
    if not aOk:
        return False
    if not bOk:
        return True
    if KING_LONGEST and a.id != b.id:
        sa = a.len + (KING_MARGIN if a.crowned else 0)
        sb = b.len + (KING_MARGIN if b.crowned else 0)
        if sa != sb:
            return sa > sb
        return a.id < b.id
    if a.id != b.id:
        return a.id < b.id
    return a.round > b.round or (a.round == b.round and a.len > b.len)


def offerKing(k):
    global bestKing
    if kingBetter(k, bestKing):
        bestKing = k.copy()


def offerEnemy(k):
    global enemyBig
    if fresher(k, enemyBig, ENEMY_STALE):
        enemyBig = k.copy()


def processComms():
    for v in E.sonarIn:
        r = decodeMsg(v)
        if r is None:
            continue
        typ, k = r
        if typ == MSG_KING:
            offerKing(k)
        else:
            offerEnemy(k)
    me = KInfo()
    me.valid, me.id, me.tile, me.len, me.round, me.crowned = True, E.myId, E.myHeadTile, E.myLen, E.roundNum, wasKing
    offerKing(me)
    for dv in E.dragons:
        if dv.id == E.myId or dv.head < 0:
            continue
        k = KInfo()
        k.valid, k.id, k.tile, k.len, k.round = True, dv.id, dv.head, dv.len, E.roundNum
        if dv.team == E.myTeam:
            if bestKing.valid and bestKing.id == dv.id:
                k.crowned = bestKing.crowned
                k.len = max(k.len, bestKing.len)
            offerKing(k)
        elif dv.len >= 6:
            offerEnemy(k)
    if bestKing.valid and bestKing.id != E.myId and bestKing.tile in E.vis_set and E.roundNum - bestKing.round <= 1:
        if not any(dv.id == bestKing.id for dv in E.dragons):
            bestKing.valid = False
    if enemyBig.valid and enemyBig.tile in E.vis_set and E.roundNum - enemyBig.round <= 2:
        if not any(dv.id == enemyBig.id for dv in E.dragons):
            enemyBig.valid = False


# Portal probes: vision stops at portals but sonar goes through them; next turn's echoes say what
# the ray stopped on.
probeTile = -1
probeDir = -1
probeRound = -10
probeKnown = False
probeClear = False
nextHeadTile = -1
nextFacing = 0


def readProbe():
    global probeKnown, probeClear
    probeKnown = False
    if probeRound == E.roundNum - 1 and probeTile == E.myHeadTile:
        probeKnown = True
        e = E.echoes
        probeClear = e[1] + e[2] + e[3] + e[4] == 0


def emitSonar():
    global probeTile, probeDir, probeRound
    rn = E.roundNum
    haveEnemy = enemyBig.valid and rn - enemyBig.round <= ENEMY_STALE
    haveKing = bestKing.valid and rn - bestKing.round <= KING_STALE
    probe = -1
    if nextHeadTile >= 0:
        for d in range(4):
            if probe >= 0:
                break
            if d == ((nextFacing + 2) & 3):
                continue   # that ray would leave from my tail
            et, side = edgeOf(nextHeadTile, d)
            if edgeKind(et, side) == 2:
                probe = d
    probeRound = -10
    if probe >= 0:
        probeTile, probeDir, probeRound = nextHeadTile, probe, rn
    for d in range(4):
        if probe >= 0 and d != probe:
            continue
        enemyTurn = haveEnemy and ((rn + d) & 1) == 0
        if enemyTurn:
            v = encodeMsg(MSG_ENEMY, enemyBig)
        elif haveKing:
            v = encodeMsg(MSG_KING, bestKing)
        elif d == probe:
            v = 0
        else:
            continue
        E.emit("SONAR %s %d\n" % (DCH[d], v))


# ---------------------------------------------------------------- roles
HARVEST, KING, FEEDER, HUNTER = range(4)
role = HARVEST
kingTile = kingId = -1
kingDir = 0
kingVisible = False
huntTile = -1
rallyTile = spawnTile = -1


def endgame():
    return E.roundNum >= R_GATHER


def dragonValue(ln, king):
    return ln * KING_VAL_MUL + KING_VAL_ADD if king else ln + UNIT_VALUE


def computeRally():
    """The anchor where our king lives in the endgame: our spawn centroid, moved to open ground."""
    global rallyTile
    rallyTile = spawnTile
    if not E.mapKnown:
        return
    m = MD.MAPS[E.mapIndex]
    p = m["dragons"]
    i = sx = sy = n = 0
    for _ in range(m["ndragons"]):
        team, ln = p[i], p[i + 1]
        if team == E.myTeam:
            sx += p[i + 2]
            sy += p[i + 3]
            n += 1
        i += 2 + 2 * ln
    if n == 0:
        return
    c = E.tileOf(sx // n, sy // n)
    step_l, gmax_l = E.step_l, E.gmax_l
    dist = {c: 0}
    q = [c]
    qh = 0
    while qh < len(q):
        u = q[qh]
        qh += 1
        opn = sum(1 for v in step_l[u] if v >= 0)
        if opn >= 3 and gmax_l[u] != 0:
            rallyTile = u
            return
        for v in step_l[u]:
            if v < 0 or v in dist:
                continue
            dist[v] = dist[u] + 1
            q.append(v)
    rallyTile = c


# ---------------------------------------------------------------- actions
class Action:
    __slots__ = ("kind", "dirs", "n", "split")

    def __init__(self, kind=0, dirs=(), split=0):
        self.kind = kind          # 0 move, 1 split, 2 die in place (feeding)
        self.dirs = list(dirs)
        self.n = len(self.dirs)
        self.split = split


class Eval:
    __slots__ = ("valid", "dead", "ram", "threatened", "trapped", "score")

    def __init__(self):
        self.valid = False
        self.dead = False
        self.ram = False
        self.threatened = False
        self.trapped = False
        self.score = -1e18


iAmKing = False
myVal = 0.0
distGoal = None
goalTile = -1
aggrNow = AGGRESSION


def findDragon(did):
    for dv in E.dragons:
        if dv.id == did:
            return dv
    return None


EXPOSE_P = (0.0, 0.45, 0.2, 0.06)


def evalAction(a):
    ev = Eval()
    ev.valid = True
    score = 0.0
    newLen = E.myLen
    step_l = E.step_l
    myHead = E.myHeadTile
    if a.kind == 2:
        # feeding: die where I stand, next to the king's head
        ev.dead = True
        ev.score = -1e9
        if role == FEEDER and kingVisible:
            for q in step_l[kingTile]:
                if q == myHead:
                    ev.score = 50.0 + E.myLen
        return ev
    if a.kind == 1 and iAmKing and NO_KING_SPLIT:
        ev.valid = False
        return ev
    if a.kind == 1:
        k = a.split
        newLen = E.myLen - k
        newBody = E.myBody[:newLen]
        # the parent stands still; is it trapped where it stands?
        pNeed = newLen + 3
        parentTrapped = spaceCount(newBody, newLen, pNeed, False) < pNeed
        # the child: my rear k segments, reversed, head at my old tail
        childOk = False
        childPen = 0.0
        if E.bodyExact and len(E.myBody) == E.myLen:
            child = E.myBody[::-1][:k]
            cNeed = k + 3
            cOpt = spaceCount(child, k, cNeed, False, newBody)
            childOk = cOpt >= cNeed
            if not childOk:
                childPen = (dragonValue(k, False) + 3.0) * (1.0 - cOpt / cNeed) * 1.5
            else:
                # the child moves last in the round: it needs room nobody else can take first
                cT = max(k + 4, 8)
                cTerr = spaceCount(child, k, cT, True, newBody)
                if cTerr < k + 2:
                    childOk = False
                    childPen = dragonValue(k, False) + 1.0
                elif cTerr < cT:
                    childPen = 0.6 * (1.0 - cTerr / cT) * (dragonValue(k, False) + 1.0)
        else:
            childPen = 1.0
        score -= childPen
        escape = parentTrapped and childOk
        if escape:
            score += 1.0       # saving k segments beats dying with all of them
        elif endgame() or role == KING or role == FEEDER:
            score -= 6.0
        elif k == 2 and E.unitCount < UNIT_TARGET:
            score += SPLIT_BONUS
        elif k == 2:
            score -= 2.0       # enough heads: grow instead
        else:
            score -= 1.0       # unusual sizes only as escapes
        # the parent stands still this turn: it must have a way out next turn
        exits = 0
        for q in step_l[myHead]:
            if q < 0 or (q in E.vis_set and q in E.occ):
                continue
            if distEnemy[q] <= 1:
                continue
            exits += 1
        if not escape and exits < 2:
            score -= SPLIT_BONUS + 1.0
    else:
        so = E.simulateMove(a.dirs, a.n)
        if so.dead:
            ev.dead = True
            if so.killId >= 0:
                e = findDragon(so.killId)
                if e is not None and isEnemyTeam(e.team):
                    gain = dragonValue(e.len, False) - myVal + aggrNow
                    if E.unitCount <= 1:
                        gain -= 100.0        # my death ends the game
                    if e.len >= 7:
                        gain += 0.7 * (e.len - 6)   # big ones are their kings
                    if E.roundNum >= FINALE and not iAmKing and e.len >= 6:
                        gain += 2.0 * e.len  # only the longest counts at the end
                    ev.ram = True
                    ev.score = gain - 0.01 * a.n
                    return ev
            score = -myVal - 5.0 - (1.0 if a.n > 1 else 0.0)
            if so.killId >= 0:
                # never take a teammate down with me
                f = findDragon(so.killId)
                score -= 10.0 + (dragonValue(f.len, False) if f is not None else 5.0)
            ev.score = score
            return ev
        newBody = so.body
        newLen = so.newLen
        score += EAT_W * so.eaten
        # feeders leave the pearls around the king to the king
        if role == FEEDER and kingTile >= 0 and so.eaten > 0 and manhattan(so.body[0], kingTile) <= 4:
            score -= (EAT_W + 0.6) * so.eaten
        # every extra step burns a segment: price it like the pearl it undoes
        score -= SPRINT_W * (a.n - 1)
        if iAmKing and E.roundNum >= FINALE:
            score -= 3.0 * (a.n - 1)
        if so.throughUnknown:
            # through a portal into tiles I cannot see: the exit may hold a head or a body
            v = dragonValue(so.newLen, iAmKing)
            risk = PORTAL_RISK
            if probeKnown and a.dirs[0] == probeDir:
                risk = PROBE_CLEAR_RISK if probeClear else 0.6
            dest = so.body[0] if so.body else -1
            if dest >= 0 and E.lastSeen[dest] >= 0:
                since = E.roundNum - int(E.lastSeen[dest])
                if E.roundNum - int(E.lastOccRound[dest]) <= 3:
                    risk = 0.8
                elif since <= 2:
                    risk = min(risk, 0.04)
            # team convention: cross portals northwards / eastwards
            cur = myHead
            for i in range(a.n):
                et, side = edgeOf(cur, a.dirs[i])
                if edgeKind(et, side) == 2 and (a.dirs[i] == 2 or a.dirs[i] == 3):
                    risk += PORTAL_WRONGWAY
                    break
                cur = step_l[cur][a.dirs[i]]
                if cur < 0:
                    break
            score -= 0.3 + PORTAL_W * v + risk * (v + 2.0)
            if dest >= 0 and deadEnd[dest]:
                score -= v
    if not newBody:
        ev.valid = False
        return ev
    newHead = newBody[0]

    if iAmKing and deadEnd[newHead] and not deadEnd[myHead]:
        score -= 4.0 + 0.5 * newLen

    # threats: enemies that can reach my new head before my next turn
    newVal = dragonValue(newLen, iAmKing)
    worst = ssum = 0.0
    for dv in E.dragons:
        if dv.id == E.myId or dv.head < 0 or not isEnemyTeam(dv.team):
            continue
        reach = reachOf(dv)
        k = reachSteps(dv.head, newHead, reach, newBody)
        if k > reach:
            continue
        pk = 1.0 if k <= 1 else (THR_P2 if k == 2 else THR_P3)
        loss = newVal - dragonValue(dv.len, False)
        evenCost = EVEN_TRADE_EARLY * newVal if E.roundNum < EARLY_ROUNDS else 0.1
        if loss > 0.5:
            pen = 0.9 * loss + max(evenCost, EVEN_EXPOSE)
        elif loss > -0.5:
            pen = max(evenCost, EVEN_EXPOSE)
        else:
            pen = evenCost
        if E.unitCount + (1 if a.kind == 1 else 0) <= 1:
            pen += LAST_UNIT_PEN   # losing my last dragon loses the game
        pen *= pk
        worst = max(worst, pen)
        ssum += pen
        if pen >= THR_MIN:
            ev.threatened = True
    if iAmKing and E.roundNum >= FINALE:
        worst *= 2.0
        ssum *= 2.0
    score -= worst + 0.2 * ssum

    # exposure: unseen tiles a few steps away may hold an attacker
    atRisk = newVal - dragonValue(3, False)
    if atRisk > 0.5 and (iAmKing or EXPOSE_ALL):
        ud = unseenDist(newHead, newBody, 3)
        if ud <= 3:
            score -= atRisk * EXPOSE_P[ud]

    # space: never walk into a pocket smaller than me
    need = newLen + 3
    opt = spaceCount(newBody, newLen, need, False)
    if opt < need:
        ev.trapped = True
        # A dead end full of pearls is a mill: eat to the end, split, and let the child walk out.
        pocket = 0.0
        contestedPocket = False
        q = lastSpaceQueue
        for i in range(1, opt):
            t = q[i]
            if t in E.vis_set and t in E.pearl_set:
                pocket += 1.0
            elif 0 < E.gmax_l[t] <= 2:
                pocket += 0.7
            if distEnemy[t] <= 2 or distAlly[t] <= 1:
                contestedPocket = True
        pocketGain = int(pocket)
        if a.kind == 0 and not contestedPocket and E.unitCount < E.unitLimit and newLen + pocketGain >= 4 and role != KING:
            score -= (2.0 + UNIT_VALUE) - 0.9 * pocket
        else:
            score -= (newVal + 3.0) * (1.0 - opt / need) * 1.5
    else:
        tw = KING_TERR_W if iAmKing else TERR_W
        if tw > 0:
            needT = max(2 * newLen, 14) if iAmKing else max(newLen + 4, 8)
            terr = spaceCount(newBody, newLen, needT, True)
            if terr < needT:
                score -= tw * (1.0 - terr / needT) * (newVal + 1.0)

    # survival: is there any way to live through the next few turns?
    if (SURV_ON or (SURV_KING and iAmKing)) and not ev.trapped:
        want = min(SURV_KING_DEPTH, newLen + 4) if iAmKing else min(SURV_DEPTH, newLen + 4)
        got = survivalDepth(newBody, newLen, want)
        if got < want:
            score -= (newVal + 2.0) * (1.0 - got / want) * 1.2
            ev.trapped = True

    # navigation
    if role in (FEEDER, HUNTER) and distGoal[newHead] < INF:
        score -= 0.6 * distGoal[newHead]
        score += 0.2 * POT_W * potentialAt(newHead)
    elif role in (FEEDER, HUNTER) and goalTile >= 0:
        score -= 0.6 * (manhattan(newHead, goalTile) + 8)
    else:
        score += POT_W * potentialAt(newHead)
        if YIELD_W > 0:
            score += YIELD_W * yieldAt(newHead)
        if iAmKing and rallyTile >= 0 and E.roundNum >= R_GATHER:
            dr = manhattan(newHead, rallyTile)
            if dr > 6:
                score -= 0.15 * (dr - 6)
        if iAmKing:
            score += (KING_POT_MUL - 1.0) * POT_W * potentialAt(newHead)
        if role == HARVEST and endgame() and kingTile >= 0 and kingId != E.myId:
            score -= 0.06 * manhattan(newHead, kingTile)

    # crowding: stay out of teammates' way
    if role == HARVEST:
        crowd = 0
        for dv in E.dragons:
            if dv.id == E.myId or dv.head < 0 or dv.team != E.myTeam:
                continue
            md = manhattan(newHead, dv.head)
            if md < 5:
                crowd += 5 - md
        score -= CROWD_W * crowd

    score += (rnd64() % 1000) * (P_NOISE / 1000.0)
    ev.score = score
    return ev


# ---------------------------------------------------------------- decision
def decideRole():
    global role, kingId, kingTile, kingVisible, huntTile, kingDir, wasKing
    role = HARVEST
    kingId = -1
    kingTile = -1
    kingVisible = False
    huntTile = -1
    rn = E.roundNum
    kingKnown = bestKing.valid and rn - bestKing.round <= KING_STALE
    if kingKnown:
        kingId = bestKing.id
        kingTile = bestKing.tile
        for dv in E.dragons:
            if dv.id == kingId and dv.head >= 0:
                kingTile, kingDir, kingVisible = dv.head, dv.dir, True
        # stale hearsay: the king will be at the anchor
        if not kingVisible and rn - bestKing.round > 6 and rallyTile >= 0:
            kingTile = rallyTile
    iAmTheKing = kingKnown and kingId == E.myId
    wasKing = False
    saturatedTeam = E.unitCount >= E.unitLimit - 4
    kingTime = rn >= R_GATHER or (saturatedTeam and rn >= R_EARLYFEED) or rn >= PIPE_START or rn >= KING_START
    if iAmTheKing and kingTime:
        role = KING
        wasKing = True
        bestKing.crowned = True
        return
    # hunters: a big enemy close by is worth a small dragon of ours
    finale = rn >= FINALE
    if (HUNT_ON and enemyBig.valid and rn - enemyBig.round <= ENEMY_STALE and (E.myLen <= 6 or finale) and
            manhattan(E.myHeadTile, enemyBig.tile) <= (24 if finale else 12) and
            enemyBig.len >= max(6 if finale else 8, E.myLen + (1 if finale else 4))):
        role = HUNTER
        huntTile = enemyBig.tile
        return
    # feeding pipeline (off by default: PIPE_START > 500)
    if kingKnown and kingId != E.myId and rn >= PIPE_START:
        dk = manhattan(E.myHeadTile, kingTile)
        f = min(1.0, (rn - PIPE_START) / max(1.0, 480.0 - PIPE_START))
        radius = int(PIPE_R0 + (PIPE_R1 - PIPE_R0) * f)
        if E.myLen >= PIPE_MINLEN and dk <= radius:
            role = FEEDER
        return
    if kingKnown and kingId != E.myId and rn >= min(R_EARLYFEED, R_GATHER):
        dk = manhattan(E.myHeadTile, kingTile)
        radius = FEED_RADIUS_LATE if rn >= 450 else FEED_RADIUS
        feed = rn >= R_FEED and dk <= radius
        saturated = E.unitCount >= E.unitLimit - 4
        early = rn >= R_EARLYFEED
        if not feed and early and saturated and E.myLen >= 5 and dk <= 10:
            feed = True
        if not feed and early and saturated and E.myLen >= 8:
            feed = True
        if not feed and rn >= R_GATHER and E.myLen >= 6 and dk <= radius:
            feed = True
        if feed:
            role = FEEDER


distMe_np = distAlly_np = distEnemy_np = None


def goal_bfs(srcs, blocked_mask):
    """BFS from the goal ignoring time (the goal moves anyway)."""
    g = np.zeros(E.T + 1, dtype=np.int32)
    if blocked_mask is not None:
        g[blocked_mask] = INF
    g[E.T] = INF
    return bfs_np(srcs, g, INF - 1)[:E.T].tolist()


def chooseAndEmit():
    global distMe, distAlly, distEnemy, distMe_np, distAlly_np, distEnemy_np
    global kingVisibleNow, kingTileNow, kingIdNow, aggrNow, iAmKing, myVal, potAvoidDeadEnds
    global goalTile, distGoal, nextHeadTile, nextFacing, gatePot, potCache, yCache, _reachBase
    rn = E.roundNum
    computeDeadEnds()
    buildFreeAt()
    srcA, srcE = [], []
    for dv in E.dragons:
        if dv.id == E.myId or dv.head < 0:
            continue
        (srcE if isEnemyTeam(dv.team) else srcA).append(dv.head)
    Df = bfs_multi([[E.myHeadTile], srcA, srcE], [gateAll, gateAll, gateAll], 80)   # PORT: batched
    distMe_np, distAlly_np, distEnemy_np = Df[0], Df[1], Df[2]
    distMe, distAlly, distEnemy = distMe_np.tolist(), distAlly_np.tolist(), distEnemy_np.tolist()
    kingVisibleNow, kingTileNow, kingIdNow = False, -1, -1
    if bestKing.valid and rn - bestKing.round <= KING_STALE and rn >= KING_START:
        kingIdNow = bestKing.id
        for dv in E.dragons:
            if dv.id == kingIdNow and dv.head >= 0:
                kingVisibleNow, kingTileNow = True, dv.head
    computeTileValues()
    # trades are attrition: good when we outnumber them here, bad when they outnumber us
    ah, eh = 1, 0
    for dv in E.dragons:
        if dv.id == E.myId or dv.head < 0:
            continue
        if isEnemyTeam(dv.team):
            eh += 1
        else:
            ah += 1
    aggrNow = AGGRESSION + AGGR_BAL * (max(-3, min(3, ah - eh)) / 3.0)
    potCache, yCache, _reachBase = {}, {}, {}
    if YIELD_W > 0:
        computeRates()
    decideRole()
    iAmKing = role == KING
    myVal = dragonValue(E.myLen, iAmKing)
    potAvoidDeadEnds = iAmKing
    if potAvoidDeadEnds:
        gatePot = gateAll.copy()
        gatePot[deadEnd_np] = INF
    else:
        gatePot = gateAll
    goalTile = -1
    distGoal = None
    if role == FEEDER and kingTile >= 0:
        goalTile = kingTile
        srcs = []
        if kingVisible:
            for q in E.step_l[kingTile]:
                if q >= 0 and not (q in E.vis_set and q in E.occ):
                    srcs.append(q)
        if not srcs:
            srcs = [kingTile]
        blocked = [t for t, i in E.occ.items() if E.parts[i][0] != E.myId]
        distGoal = goal_bfs(srcs, np.array(blocked, dtype=np.int32) if blocked else None)
    elif role == HUNTER and huntTile >= 0:
        goalTile = huntTile
        distGoal = goal_bfs([huntTile], None)
    if distGoal is None:
        distGoal = [INF] * E.T

    # PORT: the potential of every single-step destination and of standing still (split/feed) is
    # computed in one batched search up front; evalAction then finds it in the cache.
    heads = [E.myHeadTile]
    for d in range(4):
        so = E.simulateMove([d], 1)
        if not so.dead and so.body:
            heads.append(so.body[0])
    precomputePotentials(heads)

    best = Action()
    bestScore = -1e18
    anyGood = False
    rams = []

    def consider(a, e):
        nonlocal best, bestScore
        if not e.valid:
            return
        if RAM_REL and e.ram:
            rams.append((a, e.score))
            return
        if e.score > bestScore:
            bestScore = e.score
            best = a

    def out_of_time():
        # PORT: stop before the next evaluation could push the turn past the judge's limit
        return spentNs() + worstEval + WRITE_RESERVE > JUDGE_LIMIT

    def timed_eval(a):
        global worstEval
        t0 = nowNs()
        e = evalAction(a)
        dt = nowNs() - t0
        if dt > worstEval:
            worstEval = dt
        return e

    for d in range(4):
        if out_of_time():
            break
        a = Action(0, [d])
        e = timed_eval(a)
        consider(a, e)
        if e.valid and not e.dead and not e.threatened and not e.trapped:
            anyGood = True
    if E.myLen - 2 >= 2 and E.unitCount < E.unitLimit and not out_of_time():
        a = Action(1, split=2)
        consider(a, timed_eval(a))
        if not anyGood:
            for k in range(3, E.myLen - 1):
                if out_of_time():
                    break
                b = Action(1, split=k)
                consider(b, timed_eval(b))
    if role == FEEDER and kingVisible and not out_of_time():
        a = Action(2)
        consider(a, evalAction(a))
    # sprints: rams (cheap to find) and escapes (only when nothing is good)
    maxSteps = min(E.myLen - 1, 4)
    for n in range(2, maxSteps + 1):
        if spentNs() > SOFT_BUDGET:
            break
        for code in range(1 << (2 * n)):
            c = code
            dirs = []
            reversal = False
            for i in range(n):
                dd = c & 3
                c >>= 2
                if i > 0 and dd == ((dirs[-1] + 2) & 3):
                    reversal = True
                dirs.append(dd)
            if reversal:
                continue
            if out_of_time():
                break
            so = E.simulateMove(dirs, n)
            if so.dead:
                if so.killId < 0:
                    continue
                a = Action(0, dirs)
                consider(a, timed_eval(a))
                continue
            if anyGood or spentNs() > SOFT_BUDGET:
                continue
            a = Action(0, dirs)
            consider(a, timed_eval(a))
    if RAM_REL and rams:
        base = bestScore if bestScore > -5.0 else -myVal - 5.0
        for a, g in rams:
            s = base + g if bestScore > -5.0 else base + g + myVal
            if s > bestScore:
                bestScore, best = s, a

    if bestScore == -1e18:
        # PORT: out of time before any candidate was scored: take any step that is not certain death
        for d in range(4):
            so = E.simulateMove([d], 1)
            if not so.dead:
                best = Action(0, [d])
                break
    nextHeadTile = -1
    if best.kind == 1:
        nextHeadTile, nextFacing = E.myHeadTile, E.myDirection
    elif best.kind == 0 and best.n > 0:
        cur = E.myHeadTile
        for i in range(best.n):
            if cur < 0:
                break
            cur = E.step_l[cur][best.dirs[i]]
        nextHeadTile = cur
        nextFacing = best.dirs[best.n - 1]
    E.prevActKind = best.kind
    E.prevActN = best.n
    E.prevActDirs = list(best.dirs) + [0] * (8 - best.n)
    if best.kind == 0 and best.n == 0:
        E.prevActN = 1
        E.prevActDirs[0] = 0
    if best.kind == 2:
        E.emit("SPLIT 1\n")   # illegal on purpose: the dragon dies where it stands
    elif best.kind == 1:
        E.emit("SPLIT %d\n" % best.split)
    else:
        E.emit("MOVE %s\n" % ("".join(DCH[d] for d in best.dirs) if best.n else "N"))


# ---------------------------------------------------------------- main
def main():
    global turnStartNs, spawnTile, rallyTile, _scratch, _arange
    import sys
    tk = E.readLine()
    if tk is None:
        return
    E.myId = int(tk[1])
    E.myTeam = 0 if E.readLine()[1][0] == 65 else 1
    tk = E.readLine()
    E.initState(int(tk[1]), int(tk[2]))
    E.unitLimit = int(E.readLine()[1])
    E.rngState ^= (((E.myId + 1) * 0x9E3779B97F4A7C15) & M64) ^ ((P_SEED * 0xD1B54A32D192ED03) & M64)
    _scratch = np.empty(E.T + 1, dtype=np.int32)
    _arange = np.arange(4 * (E.T + 1), dtype=np.int32)
    E.candidates = [i for i, m in enumerate(MD.MAPS) if m["w"] == E.W and m["h"] == E.H]
    if not E.candidates:
        E.initLearned()
        E.mapIndex = -2
        E.identified = True
    else:
        E.loadEmbedded(E.candidates[0])
    write = sys.stdout.write
    flush = sys.stdout.flush
    while True:
        if not E.readTurn():
            break
        turnStartNs = E.turnStart  # PORT: includes parsing, which costs real points in Python
        E.out = []
        E.identifyMap()
        E.learnFromObservations()
        E.buildDragons()
        E.updateMyBody()
        if E.turnsAlive == 0:
            spawnTile = E.myHeadTile
        if rallyTile < 0 or E.turnsAlive == 0:
            computeRally()
        E.updateMemory()
        updateDensity()
        processComms()
        readProbe()
        chooseAndEmit()
        emitSonar()
        E.emit("PROTOCOL 3\nENDTURN\n")
        write("".join(E.out))
        flush()
        E.turnsAlive += 1


if __name__ == "__main__":
    main()
