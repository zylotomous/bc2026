"""Engine layer, ported line for line from the C++ bot's engine.hpp.

Geometry, the static map (embedded or learned), raw protocol I/O (protocol 3: directional 64-bit
sonar and ECHOES), perception of the 7x7 window, dead-reckoned tracking of our own body, and exact
simulation of our own moves.

Port notes (performance only, behaviour unchanged):
  * Whole-map loops (map loading, computeSteps, dead ends, memory updates) are vectorised with numpy.
    In the judge a Python bytecode costs tens of points and a numpy call ~10-50k, so a 4096-tile
    Python loop can cost more than the whole 100M turn budget.
  * Per-tile arrays that the strategy reads one element at a time in hot loops are mirrored as plain
    Python lists/sets/dicts (numpy scalar indexing is slow); arrays used in vector code stay numpy.
  * `step_np` is stepTo with -1 replaced by a sentinel tile T (all per-tile numpy arrays have a
    T+1'th entry that is permanently blocked), which removes a filter from every vectorised BFS.
"""
import sys
import time

import numpy as np

import maps_data as MD

MAXT = 64 * 64
DX = (0, 1, 0, -1)
DY = (-1, 0, 1, 0)
DCH = "NESW"
INF = 1 << 28
M64 = (1 << 64) - 1
DIR_OF = {ord("N"): 0, ord("E"): 1, ord("S"): 2, ord("W"): 3}

W = H = T = 0


def tileOf(x, y):
    return (y % H) * W + (x % W)


def tx(t):
    return t % W


def ty(t):
    return t // W


def wrapDist(a, b, n):
    d = a - b
    if d < 0:
        d = -d
    return d if d < n - d else n - d


def manhattan(a, b):
    return wrapDist(a % W, b % W, W) + wrapDist(a // W, b // W, H)


def gridNb(t, d):
    return tileOf(t % W + DX[d], t // W + DY[d])


# ---------------------------------------------------------------- rng (xorshift, as in C++)
rngState = 88172645463325252


def rnd64():
    global rngState
    x = rngState
    x ^= (x << 7) & M64
    x ^= x >> 9
    rngState = x
    return x


# ---------------------------------------------------------------- clock
# In the judge the clock advances one nanosecond per CPU point spent, so this measures points.
nowNs = time.perf_counter_ns

# ---------------------------------------------------------------- static map
# Edge kinds: 0 open, 1 kelp, 2 portal, -1 unknown (learned maps only).
edgeN = edgeW = portalN = portalW = gmin = gmax = None
gmax_l = gmin_l = None
stepTo = None      # numpy (T,4) int32, -1 blocked/unknown
step_l = None      # same as nested Python lists, for scalar code
step_np = None     # (T+1,4) int32 with -1 -> T (sentinel), for vectorised BFS
mapKnown = False
mapIndex = -1
symType = ""
portalEnds = {}    # id -> list of (tile, side)
_decoded = {}      # embedded map index -> (edge kinds (T,2) int8, gmax per tile) for matchesMap

LUT = np.full(256, -1, dtype=np.int32)
for _i, _c in enumerate(MD.ALPH):
    LUT[ord(_c)] = _i


def mirrorTile(t):
    x, y = t % W, t // W
    if symType == "y":
        return tileOf(W - 1 - x, y)
    if symType == "x":
        return tileOf(x, H - 1 - y)
    if symType == "r":
        return tileOf(W - 1 - x, H - 1 - y)
    return -1


def edgeOf(t, d):
    """Edge crossed when leaving tile t in direction d, as (tile, side) with side 0 north, 1 west."""
    if d == 0:
        return t, 0
    if d == 2:
        return gridNb(t, 2), 0
    if d == 3:
        return t, 1
    return gridNb(t, 1), 1


def edgeKind(et, side):
    return int(edgeN[et]) if side == 0 else int(edgeW[et])


def edgePortal(et, side):
    return int(portalN[et]) if side == 0 else int(portalW[et])


def addPortalEnd(pid, t, side):
    if pid < 0:
        return
    lst = portalEnds.setdefault(pid, [])
    if (t, side) not in lst:
        lst.append((t, side))


def computeSteps():
    global stepTo, step_l, step_np
    t = np.arange(T, dtype=np.int32)
    x, y = t % W, t // W
    nb = [((y - 1) % H) * W + x, y * W + (x + 1) % W, ((y + 1) % H) * W + x, y * W + (x - 1) % W]
    # edge crossed per direction: N -> own north, E -> east nb's west, S -> south nb's north, W -> own west
    kinds = [edgeN[t], edgeW[nb[1]], edgeN[nb[2]], edgeW[t]]
    st = np.empty((T, 4), dtype=np.int32)
    for d in range(4):
        col = nb[d].astype(np.int32)
        col[kinds[d] == 1] = -1
        st[:, d] = col
        for tt in np.flatnonzero(kinds[d] == 2).tolist():
            et, side = edgeOf(tt, d)
            pid = edgePortal(et, side)
            dest = -1
            ends = portalEnds.get(pid)
            if pid >= 0 and ends is not None and len(ends) == 2:
                o = ends[0]
                if o[0] == et and o[1] == side:
                    o = ends[1]
                if o[1] == 0:
                    dest = gridNb(o[0], 0) if d == 0 else o[0]   # horizontal edge
                else:
                    dest = gridNb(o[0], 3) if d == 3 else o[0]   # vertical edge
            st[tt, d] = dest
    stepTo = st
    step_l = st.tolist()
    sn = np.full((T + 1, 4), T, dtype=np.int32)
    sn[:T] = np.where(st < 0, T, st)
    step_np = sn


def _decode(idx):
    if idx not in _decoded:
        m = MD.MAPS[idx]
        e = np.frombuffer(m["edges"], dtype=np.uint8).reshape(-1, 2)
        kinds = np.where(e == ord("."), 0, np.where(e == ord("w"), 1, 2)).astype(np.int8)
        pal = np.array(m["pal"], dtype=np.int32).reshape(-1, 2)
        p = LUT[np.frombuffer(m["tiles"], dtype=np.uint8)]
        _decoded[idx] = (kinds, pal[p, 0], pal[p, 1])
    return _decoded[idx]


def loadEmbedded(idx):
    global mapIndex, mapKnown, edgeN, edgeW, portalN, portalW, gmin, gmax, gmin_l, gmax_l, symType
    m = MD.MAPS[idx]
    mapIndex = idx
    mapKnown = True
    kinds, gmn, gmx = _decode(idx)
    gmin = gmn.astype(np.int16)
    gmax = gmx.astype(np.int16)
    gmin_l = gmin.tolist()
    gmax_l = gmax.tolist()
    edgeN = kinds[:, 0].copy()
    edgeW = kinds[:, 1].copy()
    portalN = np.full(T, -1, dtype=np.int32)
    portalW = np.full(T, -1, dtype=np.int32)
    portalEnds.clear()
    pr = m["portals"]
    for i in range(len(pr) // 3):
        t, side, pid = pr[3 * i], pr[3 * i + 1], pr[3 * i + 2]
        if side == 0:
            portalN[t] = pid
        else:
            portalW[t] = pid
        addPortalEnd(pid, t, side)
    symType = {"xy": "r", "y": "y", "x": "x"}.get(m["sym"], "")
    computeSteps()


def initLearned():
    global mapKnown, mapIndex, edgeN, edgeW, portalN, portalW, gmin, gmax, gmin_l, gmax_l
    mapKnown = False
    mapIndex = -1
    edgeN = np.full(T, -1, dtype=np.int8)
    edgeW = np.full(T, -1, dtype=np.int8)
    portalN = np.full(T, -1, dtype=np.int32)
    portalW = np.full(T, -1, dtype=np.int32)
    gmin = np.full(T, -1, dtype=np.int16)
    gmax = np.full(T, -1, dtype=np.int16)
    gmin_l = gmin.tolist()
    gmax_l = gmax.tolist()
    portalEnds.clear()
    computeSteps()


# ---------------------------------------------------------------- input
_in = sys.stdin.buffer


def readLine():
    """Next non-blank line as a list of byte tokens (comments after '#' stripped), or None at EOF."""
    while True:
        b = _in.readline()
        if not b:
            return None
        h = b.find(b"#")
        if h >= 0:
            b = b[:h]
        tk = b.split()
        if tk:
            return tk


# ---------------------------------------------------------------- game state
myId = 0
myTeam = 0
unitLimit = 64
roundNum = 0
myDirection = 0
myLen = 3
unitCount = 1
sonarIn = []
echoes = [0, 0, 0, 0, 0]
turnsAlive = 0
turnStart = 0

vis_np = None          # numpy bool (T+1)
vis_set = set()
visList = [0] * 49
winX0 = winY0 = 0
pearl_set = set()      # visible tiles holding a pearl this turn
countdownNow = {}      # visible tile -> countdown

lastSeen = None        # numpy int32, -1 never
pearlMem = None        # numpy bool
spawnAt = None         # numpy int32, -1 unknown
neverSpawns = None     # numpy bool
lastOccRound = None    # numpy int32

parts = []             # (id, team, dir, head)
partTile = []
occ = {}               # visible tile -> index into parts


class DragonView:
    __slots__ = ("id", "team", "head", "dir", "chain", "nparts", "exact", "len")


dragons = []
myBody = []
prevBody = []
bodyExact = False
myHeadTile = -1

out = []               # output lines for this turn


def emit(s):
    out.append(s)


# ---------------------------------------------------------------- map identification
candidates = []
identified = False
edgeObs = []   # (t, side, kind, portal)
tileObs = []   # (t, countdown)


_obsArrays = None   # (edge tiles, sides, kinds, tile-obs tiles, never-spawn flags), built once per turn


def _obs():
    global _obsArrays
    if _obsArrays is None:
        n = len(edgeObs)
        et = np.fromiter((e[0] for e in edgeObs), dtype=np.int32, count=n)
        es = np.fromiter((e[1] for e in edgeObs), dtype=np.int32, count=n)
        ek = np.fromiter((e[2] for e in edgeObs), dtype=np.int8, count=n)
        tt = np.fromiter((o[0] for o in tileObs), dtype=np.int32, count=len(tileObs))
        tn = np.fromiter((o[1] < 0 for o in tileObs), dtype=bool, count=len(tileObs))
        _obsArrays = (et, es, ek, tt, tn)
    return _obsArrays


def matchesMap(idx):
    """PORT: same test as C++ (every observed edge kind and spawn flag agrees), vectorised."""
    m = MD.MAPS[idx]
    if m["w"] != W or m["h"] != H:
        return False
    kinds, _, gmx = _decode(idx)
    et, es, ek, tt, tn = _obs()
    if not np.array_equal(kinds[et, es], ek):
        return False
    return bool(np.array_equal(gmx[tt] == 0, tn))


def identifyMap():
    global candidates, identified, mapIndex
    if identified:
        if mapKnown and not matchesMap(mapIndex):
            initLearned()   # the world disagrees with the embedded map: fall back to learning
        return
    keep = [c for c in candidates if matchesMap(c)]
    candidates = keep
    if len(candidates) == 1:
        loadEmbedded(candidates[0])
        identified = True
    elif not candidates:
        if mapKnown or mapIndex != -2:
            initLearned()
        mapIndex = -2
        identified = True
    else:
        loadEmbedded(candidates[0])   # ambiguous for now: plan with the first candidate


def learnFromObservations():
    if mapKnown:
        return
    changed = False
    for t, side, kind, pid in edgeObs:
        if side == 0:
            if edgeN[t] != kind or portalN[t] != pid:
                edgeN[t] = kind
                portalN[t] = pid
                changed = True
                if kind == 2:
                    addPortalEnd(pid, t, side)
        else:
            if edgeW[t] != kind or portalW[t] != pid:
                edgeW[t] = kind
                portalW[t] = pid
                changed = True
                if kind == 2:
                    addPortalEnd(pid, t, side)
    for t, cd in tileObs:
        if cd < 0:
            neverSpawns[t] = True
            gmin[t] = 0
            gmax[t] = 0
            gmin_l[t] = 0
            gmax_l[t] = 0
    if changed:
        computeSteps()


# ---------------------------------------------------------------- turn parsing
def _kind(tok):
    c = tok[0]
    return 0 if c == 46 else (1 if c == 119 else 2)   # '.', 'w', else portal id


def readTurn():
    global roundNum, myDirection, myLen, unitCount, sonarIn, echoes, winX0, winY0
    global parts, partTile, occ, edgeObs, tileObs, pearl_set, countdownNow, vis_set, _obsArrays
    _obsArrays = None
    global turnStart
    tk = readLine()
    if tk is None or tk[0] == b"ENDGAME" or tk[0] != b"ROUND" or len(tk) < 2:
        return False
    turnStart = nowNs()   # the turn starts when its first line arrives (not while blocked waiting)
    roundNum = int(tk[1])
    myDirection = DIR_OF[readLine()[1][0]]
    myLen = int(readLine()[1])
    unitCount = int(readLine()[1])
    nm = int(readLine()[1])
    sonarIn = [int(readLine()[0]) for _ in range(nm)]
    tk = readLine()
    echoes = [0, 0, 0, 0, 0]
    if tk[0] == b"ECHOES":
        for i in range(min(5, len(tk) - 1)):
            echoes[i] = int(tk[i + 1])
        tk = readLine()
    for t in visList:
        vis_np[t] = False
    vis_set = set()
    pearl_set = set()
    countdownNow = {}
    tileObs = []
    for i in range(49):
        if i > 0:
            tk = readLine()
        x, y, hp, cd = int(tk[0]), int(tk[1]), int(tk[2]), int(tk[3])
        if i == 0:
            winX0, winY0 = x, y
        t = (y % H) * W + (x % W)
        visList[i] = t
        vis_set.add(t)
        if hp:
            pearl_set.add(t)
        countdownNow[t] = cd
        tileObs.append((t, cd))
    for t in visList:
        vis_np[t] = True
    tk = readLine()
    nb = int(tk[1])
    parts = []
    partTile = []
    occ = {}
    for _ in range(nb):
        tk = readLine()
        team = 0 if tk[0][0] == 65 else 1
        pid = int(tk[1])
        t = (int(tk[3]) % H) * W + (int(tk[2]) % W)
        occ[t] = len(parts)
        parts.append((pid, team, DIR_OF[tk[4][0]], int(tk[5]) != 0))
        partTile.append(t)
    edgeObs = []
    for j in range(8):
        tk = readLine()
        y = winY0 + j
        for c in range(min(7, len(tk))):
            k = _kind(tk[c])
            edgeObs.append((((y % H) * W + ((winX0 + c) % W)), 0, k, int(tk[c]) if k == 2 else -1))
    for j in range(7):
        tk = readLine()
        y = winY0 + j
        for c in range(min(8, len(tk))):
            k = _kind(tk[c])
            edgeObs.append((((y % H) * W + ((winX0 + c) % W)), 1, k, int(tk[c]) if k == 2 else -1))
    return True


# ---------------------------------------------------------------- perception
def buildDragons():
    global dragons
    dragons = []
    ids = sorted({p[0] for p in parts})
    for did in ids:
        dv = DragonView()
        dv.id = did
        dv.team = -1
        dv.head = -1
        dv.dir = 0
        dv.nparts = 0
        dv.exact = False
        dv.chain = []
        for i, p in enumerate(parts):
            if p[0] != did:
                continue
            dv.team = p[1]
            dv.nparts += 1
            if p[3]:
                dv.head = partTile[i]
                dv.dir = p[2]
        if dv.head >= 0:
            dv.chain.append(dv.head)
            cur = dv.head
            while True:
                nxt = -1
                unknownNb = False
                srow = step_l[cur]
                for d in range(4):
                    q = srow[d]
                    if q < 0:
                        et, side = edgeOf(cur, d)
                        if edgeKind(et, side) != 1:
                            unknownNb = True   # could be a portal we do not know
                        continue
                    if q not in vis_set:
                        unknownNb = True
                        continue
                    oi = occ.get(q, -1)
                    if oi < 0:
                        continue
                    op = parts[oi]
                    if op[0] != did or op[3]:
                        continue
                    if step_l[q][op[2]] != cur:
                        continue
                    if q in dv.chain:
                        continue
                    nxt = q
                    break
                if nxt < 0:
                    dv.exact = not unknownNb
                    break
                dv.chain.append(nxt)
                cur = nxt
                if len(dv.chain) > 64 * 64:
                    break
        dv.len = max(dv.nparts, len(dv.chain))
        if dv.head >= 0 and dv.exact and len(dv.chain) < dv.nparts:
            dv.exact = False
        dragons.append(dv)


# My own body: dead reckoning from the previous exact body and my last action (exact even out of
# sight or through a portal); vision is the fallback.
prevActKind = -1
prevActDirs = [0] * 8
prevActN = 0
prevBodyExact = False


def updateMyBody():
    global prevBody, prevBodyExact, myBody, bodyExact, myHeadTile
    prevBody = myBody
    prevBodyExact = bodyExact
    myBody = []
    me = None
    for d in dragons:
        if d.id == myId:
            me = d
    if me is None or me.head < 0:
        bodyExact = False
        return
    myHeadTile = me.head
    if prevBodyExact and prevBody and prevActKind >= 0:
        pred = []
        if prevActKind == 0:
            path = []
            cur = prevBody[0]
            ok = True
            for i in range(prevActN):
                cur = step_l[cur][prevActDirs[i]]
                if cur < 0:
                    ok = False
                    break
                path.append(cur)
            if ok:
                pred = path[::-1] + prevBody
        else:
            pred = list(prevBody)
        if len(pred) >= myLen and pred and pred[0] == myHeadTile:
            pred = pred[:myLen]
            ps = set(pred)
            consistent = all(partTile[i] in ps for i, p in enumerate(parts) if p[0] == myId)
            if consistent:
                myBody = pred
                bodyExact = True
                return
    myBody = list(me.chain)
    # my facing points from my neck to my head, so the neck is known even out of sight
    if len(myBody) == 1 and myLen >= 2:
        neck = step_l[myHeadTile][(myDirection + 2) & 3]
        if neck >= 0 and neck != myHeadTile:
            myBody.append(neck)
    if len(myBody) >= myLen:
        myBody = myBody[:myLen]
        bodyExact = True
        return
    last = myBody[-1]
    if last in prevBody:
        j = prevBody.index(last) + 1
        mb = set(myBody)
        while j < len(prevBody) and len(myBody) < myLen:
            if prevBody[j] in mb:
                break
            myBody.append(prevBody[j])
            mb.add(prevBody[j])
            j += 1
    bodyExact = len(myBody) == myLen


def updateMemory():
    vl = np.fromiter(visList, dtype=np.int32, count=49)
    first = lastSeen[vl] < 0
    lastOccRound[vl[first]] = -1000
    for t, i in occ.items():
        if parts[i][0] != myId:
            lastOccRound[t] = roundNum
    lastSeen[vl] = roundNum
    pearlMem[vl] = np.fromiter((t in pearl_set for t in visList), dtype=bool, count=49)
    cd = np.fromiter((countdownNow[t] for t in visList), dtype=np.int32, count=49)
    pos = cd >= 0
    spawnAt[vl[pos]] = roundNum + cd[pos]
    spawnAt[vl[~pos]] = -1
    neverSpawns[vl[~pos]] = True
    if symType:
        # mirrored tiles share a countdown; a visible mirror keeps its own observation
        for t, c in zip(vl[pos].tolist(), cd[pos].tolist()):
            m = mirrorTile(t)
            if m >= 0 and m not in vis_set:
                spawnAt[m] = roundNum + c


# ---------------------------------------------------------------- simulation
class SimOut:
    __slots__ = ("dead", "killId", "eaten", "newLen", "body", "throughUnknown")

    def __init__(self):
        self.dead = False
        self.killId = -1
        self.eaten = 0
        self.newLen = 0
        self.body = []
        self.throughUnknown = False


def simulateMove(dirs, n):
    o = SimOut()
    body = list(myBody)
    ln = myLen
    eatenTiles = []
    for i in range(n):
        if i > 0 and ln < 3:
            o.dead = True
            break
        cur = body[0] if body else myHeadTile
        dest = step_l[cur][dirs[i]]
        if dest < 0:
            o.dead = True
            break
        visible = dest in vis_set
        if not visible:
            o.throughUnknown = True
        if dest in body:
            o.dead = True
            break
        if visible:
            oi = occ.get(dest, -1)
            if oi >= 0:
                p = parts[oi]
                if p[0] != myId:
                    if p[3]:
                        o.killId = p[0]
                    o.dead = True
                    break
        body.insert(0, dest)
        ate = visible and dest in pearl_set and dest not in eatenTiles
        if ate:
            eatenTiles.append(dest)
            o.eaten += 1
            ln += 1
        elif body:
            if len(body) > ln:
                body.pop()
        if i > 0:
            ln -= 1
            while len(body) > ln:
                body.pop()
        while len(body) > ln:
            body.pop()
    o.newLen = ln
    o.body = body
    return o


def initState(w, h):
    """Allocate per-tile arrays once the map size is known (the C++ statics)."""
    global W, H, T, vis_np, lastSeen, pearlMem, spawnAt, neverSpawns, lastOccRound
    W, H, T = w, h, w * h
    vis_np = np.zeros(T + 1, dtype=bool)
    lastSeen = np.full(T, -1, dtype=np.int32)
    pearlMem = np.zeros(T, dtype=bool)
    spawnAt = np.full(T, -1, dtype=np.int32)
    neverSpawns = np.zeros(T, dtype=bool)
    lastOccRound = np.full(T, -1000, dtype=np.int32)
